<?php

class xautoload_test_2_ExampleClass {}
